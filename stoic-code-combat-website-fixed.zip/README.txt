STOIC CODE COMBAT — WEBSITE

The supplied SCC shield and Facebook and Instagram links are included.

Preview index.html locally. To publish for free, create a GitHub account, create a public repository named YOURUSERNAME.github.io, and upload index.html and the assets folder (including scc-shield.jpg). GitHub Pages may take a few minutes to deploy.

Your logo image includes a checkerboard background as supplied. For a truly transparent background, provide a transparent PNG.

The site is not live until published. Do not upload confidential information.
